public interface IFunction {
    public double evaluate(TVector vec);
}
